import React, { useMemo } from "react";
import {
  DataGrid,
  GridToolbar,
  GRID_CHECKBOX_SELECTION_COL_DEF,
} from "@mui/x-data-grid";

//GridToolbar can be used for Filtering columns

const DataGridComponent = ({ data, loading }) => {
  //for multi selection of rows
  //single selection is active by default
  const columns = useMemo(
    () => [
      {
        ...GRID_CHECKBOX_SELECTION_COL_DEF,
        width: 100,
      },
      ...data.columns,
    ],
    [data.columns]
  );
  return (
    <div className="data-grid">
      <DataGrid
        {...data}
        loading={loading}
        slots={{ toolbar: GridToolbar }}
        checkboxSelection
        columns={columns}
      />
    </div>
  );
};

export default DataGridComponent;
