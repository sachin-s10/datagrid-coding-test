import logo from "./logo.svg";
import "./App.css";
import DataGridComponent from "./components/DataGridComponent";
import { useDemoData } from "@mui/x-data-grid-generator";
import DataGridNormal from "./components/DataGridNormal";

const VISIBLE_FIELDS = ["name", "rating", "country", "dateCreated", "isAdmin"];

function App() {
  const { data, loading } = useDemoData({
    dataSet: "Employee",
    visibleFields: VISIBLE_FIELDS,
    rowLength: 100,
  });
  return (
    <div className="App">
      <DataGridComponent data={data} loading={loading} />
      <DataGridNormal />
    </div>
  );
}

export default App;
